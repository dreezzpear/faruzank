alert("Hello Fariz!");
